
var config = {
	mode: "fixed_servers",
    rules: {
        singleProxy: {
            scheme: "http",
            host: "176.9.29.18",
            port: parseInt(10010)
        },
        bypassList: []
	}
};

chrome.proxy.settings.set({ value: config, scope: "regular" }, function() { });

function callbackFn(details)
{
	return {
		authCredentials:
		{
			username: "LAw7Lp",
			password: "PqaF7M"
		}
	};
}

chrome.webRequest.onAuthRequired.addListener(
	callbackFn,

	{ urls:["<all_urls>"] },
    ['blocking']
);