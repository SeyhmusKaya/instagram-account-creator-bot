
var config = {
	mode: "fixed_servers",
    rules: {
        singleProxy: {
            scheme: "http",
            host: "185.226.105.58",
            port: parseInt(10000)
        },
        bypassList: []
	}
};

chrome.proxy.settings.set({ value: config, scope: "regular" }, function() { });

function callbackFn(details)
{
	return {
		authCredentials:
		{
			username: "ezSvbM",
			password: "ezSvbM"
		}
	};
}

chrome.webRequest.onAuthRequired.addListener(
	callbackFn,

	{ urls:["<all_urls>"] },
    ['blocking']
);